import rospy
import numpy as np
import time
import std_msgs
from geometry_msgs.msg import PoseStamped, TwistStamped
import transforms3d as tfs
from visualization_msgs.msg import Marker
from geometry_msgs.msg import Point
from kuadmini import Kuadmini

SPIN_RADIUS = 0.51 # 圆环中心旋转半径
START_ANGLE = 15   # 圆环旋转到该角度后开始钻环

# 圆环动捕刚体编号
ring1_number = 3
ring2_number = 5
ring3_number = 6
ring1_mc_pose = [0,0,0]
ring2_mc_pose = [0,0,0]
ring3_mc_pose = [0,0,0]
ring1_mc_euler = [0,0,0]
ring2_mc_euler = [0,0,0]
ring3_mc_euler = [0,0,0]
ring1_mc_mat = np.zeros((3,3))
ring2_mc_mat = np.zeros((3,3))
ring3_mc_mat = np.zeros((3,3))

# 圆环ROS话题回调函数
def ring1_posi_cb(msg):
    global ring1_mc_pose, ring1_mc_mat
    ring1_mc_mat = tfs.quaternions.quat2mat([-msg.pose.orientation.w, msg.pose.orientation.x,msg.pose.orientation.y,msg.pose.orientation.z])
    euler = tfs.euler.mat2euler(ring1_mc_mat, 'syxz')
    ring1_mc_euler[0] = 57.295779579 * euler[1]  # 当前roll角度
    ring1_mc_euler[1] = 57.295779579 * euler[0]  # 当前pitch角度
    ring1_mc_euler[2] = 57.295779579 * euler[2]  # 当前yaw角度
    ring1_mc_pose[0] = (msg.pose.position.x/1000)  # 当前x位置
    ring1_mc_pose[1] = (msg.pose.position.y/1000)  # 当前y位置
    ring1_mc_pose[2] = (msg.pose.position.z/1000)  # 当前z位置
# def ring2_posi_cb(msg):
#     global ring2_mc_pose
#     euler = tfs.euler.quat2euler([msg.pose.orientation.x,msg.pose.orientation.y,msg.pose.orientation.z,msg.pose.orientation.w])
#     ring2_mc_euler[0] = 57.295779579 * euler[2]  # 当前roll角度
#     ring2_mc_euler[1] = 57.295779579 * euler[1]  # 当前pitch角度
#     ring2_mc_euler[2] = 57.295779579 * euler[0]  # 当前yaw角度
#     ring2_mc_pose[0] = (msg.pose.position.x/1000)  # 当前x位置
#     ring2_mc_pose[1] = (msg.pose.position.y/1000)  # 当前y位置
#     ring2_mc_pose[2] = (msg.pose.position.z/1000)  # 当前z位置
# def ring3_posi_cb(msg):
#     global ring1_mc_pose
#     euler = tfs.euler.quat2euler([msg.pose.orientation.x,msg.pose.orientation.y,msg.pose.orientation.z,msg.pose.orientation.w])
#     ring3_mc_euler[0] = 57.295779579 * euler[2]  # 当前roll角度
#     ring3_mc_euler[1] = 57.295779579 * euler[1]  # 当前pitch角度
#     ring3_mc_euler[2] = 57.295779579 * euler[0]  # 当前yaw角度
#     ring3_mc_pose[0] = (msg.pose.position.x/1000)  # 当前x位置
#     ring3_mc_pose[1] = (msg.pose.position.y/1000)  # 当前y位置
#     ring3_mc_pose[2] = (msg.pose.position.z/1000)  # 当前z位置

Color_Red = std_msgs.msg.ColorRGBA(1, 0, 0, 1)
Color_Green = std_msgs.msg.ColorRGBA(0, 1, 0, 1)
Color_Blue = std_msgs.msg.ColorRGBA(0, 0, 1, 1)
Color_Purple = std_msgs.msg.ColorRGBA(1, 0, 1, 1)
Color_Orange = std_msgs.msg.ColorRGBA(1, 0.5, 0, 1)
Color_Yellow = std_msgs.msg.ColorRGBA(1, 1, 0, 1)
Color_White = std_msgs.msg.ColorRGBA(1, 1, 1, 1)
def show_pos_now(pub, pos, id=0, color=std_msgs.msg.ColorRGBA(1, 1, 1, 0.5)):
    points = Marker()
    points.header.frame_id = 'world'
    points.header.stamp = rospy.Time.now()
    points.ns = 'points_and_lines'
    points.pose.orientation.w = 1.0
    points.pose.orientation.x = 0.0
    points.pose.orientation.y = 0.0
    points.pose.orientation.z = 0.0
    points.action = Marker.ADD
    points.id = id
    points.type = Marker.SPHERE_LIST
    points.scale.x = 0.1
    points.scale.y = 0.1
    points.scale.z = 0.1
    points.color = color
    points.points.append(Point(pos[0], pos[1], pos[2]))
    # print(id, pos)
    pub.publish(points)

def show_arrow_now(pub, start, end, id=0, color=std_msgs.msg.ColorRGBA(1, 1, 1, 0.5)):
    points = Marker()
    points.header.frame_id = 'world'
    points.header.stamp = rospy.Time.now()
    points.ns = 'points_and_lines'
    points.pose.orientation.w = 1.0
    points.pose.orientation.x = 0.0
    points.pose.orientation.y = 0.0
    points.pose.orientation.z = 0.0
    points.action = Marker.ADD
    points.id = id
    points.type = Marker.ARROW
    points.scale.x = 0.04
    points.scale.y = 0.08
    points.scale.z = 0.2
    points.color = color
    points.points.append(Point(start[0], start[1], start[2]))
    points.points.append(Point(end[0], end[1], end[2]))
    # print(id, pos)
    pub.publish(points)

def calc_wait_point(pose, mat, radius):
    center = np.add(pose, (-radius*mat[0]).tolist()).tolist()   # 计算圆心
    horizontal_radius = (np.cross(mat[1].tolist(), [0,0,1]) * radius).tolist()  # 水平半径向量
    horizontal_point = np.add(center, horizontal_radius)    # 圆周上的水平点
    waitpoint = np.add(horizontal_point,(-0.2*mat[1]).tolist()) # 飞机等候点
    show_arrow_now(pub, center, pose, 8)
    show_arrow_now(pub, center, horizontal_point, 9)
    show_pos_now(pub, waitpoint, 10)
    return waitpoint

def goto_limit(position, destine, distence_limit):
    d_x = destine[0]-position[0]
    d_y = destine[1]-position[1]
    d_z = destine[2]-position[2]
    length = np.linalg.norm([d_x, d_y, d_z])
    limit_k = 1.0
    if length > distence_limit:
        limit_k = distence_limit/length
    dest_x = position[0] + d_x*limit_k
    dest_y = position[1] + d_y*limit_k
    dest_z = position[2] + d_z*limit_k
    return dest_x, dest_y, dest_z

def calc_vector_angle(vec1, vec2):
    vec_norm = np.linalg.norm(vec1) * np.linalg.norm(vec2)
    cos_ = np.dot(vec1, vec2)/vec_norm
    sin_ = np.linalg.norm(np.cross(vec1, vec2))/vec_norm
    return 57.295779579 * np.arctan2(sin_, cos_)

if __name__ == "__main__":

    addr_kuadmini0=('192.168.0.160',1000) # 直连地址
    # addr_kuadmini1=('192.168.0.161',1000) # 直连地址
    # addr_kuadmini2=('192.168.0.162',1000) # 直连地址
    # addr_kuadmini3=('192.168.0.163',1000) # 直连地址
    # addr_vofa=('127.0.0.1',1347)
    addr_kground=('127.0.0.1',2001) # 通过上位机转发

    rospy.init_node('kuadmini_swarm', anonymous=False, disable_signals=True)

    # 订阅圆环动捕话题
    rospy.Subscriber('/vrpn_client_node/MCServer/{}/pose'.format(ring1_number),PoseStamped,ring1_posi_cb)
    # rospy.Subscriber('/vrpn_client_node/MCServer/{}/pose'.format(ring2_number),PoseStamped,ring2_posi_cb)
    # rospy.Subscriber('/vrpn_client_node/MCServer/{}/pose'.format(ring3_number),PoseStamped,ring3_posi_cb)

    kuadmini_0 = Kuadmini(addr_kuadmini0, number=0, use_tcp=1)
    # kuadmini_1 = Kuadmini(addr_kuadmini1, number=1, use_tcp=1)
    # kuadmini_2 = Kuadmini(addr_kuadmini2, number=2, use_tcp=1)
    # kuadmini_3 = Kuadmini(addr_kuadmini3, number=3, use_tcp=1)
    # kuadmini_k = Kuadmini(addr_kground, number=2, use_tcp=1)

    pub = rospy.Publisher("traj_show", Marker, queue_size=10)

    time.sleep(1)

    # 检查场地状态（环是否摆正，飞机位置等）
    if(sum(ring1_mc_pose)==0):
        print("警告：没有收到指定的动捕话题")
        quit()
    if(np.dot(ring1_mc_mat[1], ring1_mc_mat[1,:2].tolist()+[0]) < 0.98):
        print("警告：请将圆环摆正")
        quit()

    # 测试显示
    # while True:
    #     # print(ring1_mc_pose, ring1_mc_mat[0])
    #     # show_arrow_now(pub, ring1_mc_pose, np.add(ring1_mc_pose, 0.4*ring1_mc_mat[0]).tolist(), 0)
    #     # show_arrow_now(pub, ring1_mc_pose, np.add(ring1_mc_pose, 0.4*ring1_mc_mat[1]).tolist(), 1)
    #     # show_arrow_now(pub, ring1_mc_pose, np.add(ring1_mc_pose, 0.4*ring1_mc_mat[2]).tolist(), 2)
    #     calc_wait_point(ring1_mc_pose, ring1_mc_mat, SPIN_RADIUS)
    #     # print("\r%.2f     "%np.dot(ring1_mc_mat[1], ring1_mc_mat[1,:2].tolist()+[0]),end="")
    #     horizontal_radius = (np.cross(ring1_mc_mat[1].tolist(), [0,0,1]) * SPIN_RADIUS)  # 水平半径向量
    #     theta = calc_vector_angle(ring1_mc_mat[0], horizontal_radius)
    #     if(ring1_mc_mat[0][2]<0):
    #         theta = -theta
    #     print("\r                   %.1f"%(theta),end="    ")
    #     # print("\r                   %.1f, %.1f, %.1f"%(ring1_mc_euler[0],ring1_mc_euler[1],ring1_mc_euler[2]),end="    ")
    #     time.sleep(0.1)

    # 起飞，计算等候点，飞到等候点
    print("起飞     ")
    for __ in range(5):
        kuadmini_0.takeoff()
        time.sleep(0.1)
    print("进入等候区")
    while not rospy.is_shutdown():
        wait_point = calc_wait_point(ring1_mc_pose, ring1_mc_mat, SPIN_RADIUS)
        dest_x, dest_y, dest_z = goto_limit([kuadmini_0.mc_x, kuadmini_0.mc_y, kuadmini_0.mc_z], wait_point, 0.2)
        show_pos_now(pub, [kuadmini_0.mc_x, kuadmini_0.mc_y, kuadmini_0.mc_z], 0, Color_Green)
        show_arrow_now(pub, [kuadmini_0.mc_x, kuadmini_0.mc_y, kuadmini_0.mc_z], [dest_x, dest_y, dest_z], 4)
        kuadmini_0.goto(dest_x, dest_y, dest_z)
        time.sleep(0.1)
        diff = np.linalg.norm([kuadmini_0.mc_x-wait_point[0], kuadmini_0.mc_y-wait_point[1], kuadmini_0.mc_z-wait_point[2]])
        if(diff < 0.05):
            break
    
    # 环y轴角度处于40°到15°之间时飞机在等候点保持稳定悬停，则准备钻环
    while not rospy.is_shutdown():
        keep_waiting = 1
        old_theta = 0
        while not rospy.is_shutdown():  # 等待圆环经过40°位置
            wait_point = calc_wait_point(ring1_mc_pose, ring1_mc_mat, SPIN_RADIUS)
            kuadmini_0.goto(wait_point[0], wait_point[1], wait_point[2])
            theta = calc_vector_angle(ring1_mc_mat[0], (np.cross(ring1_mc_mat[1].tolist(), [0,0,1]) * SPIN_RADIUS))
            if(ring1_mc_mat[0][2]<0):
                theta = -theta
            if(old_theta > 40 and theta < 40):
                print("预备...")
                break
            old_theta = theta
            time.sleep(0.05)
        while not rospy.is_shutdown():  # 等待圆环到达15°位置，期间飞机要保持稳定悬停
            wait_point = calc_wait_point(ring1_mc_pose, ring1_mc_mat, SPIN_RADIUS)
            kuadmini_0.goto(wait_point[0], wait_point[1], wait_point[2])
            # theta = ring1_mc_euler[1] # （直接用欧拉角横过来摆会有问题...
            theta = calc_vector_angle(ring1_mc_mat[0], (np.cross(ring1_mc_mat[1].tolist(), [0,0,1]) * SPIN_RADIUS))
            if(ring1_mc_mat[0][2]<0):
                theta = -theta
            diff = np.linalg.norm([kuadmini_0.mc_x-wait_point[0], kuadmini_0.mc_y-wait_point[1], kuadmini_0.mc_z-wait_point[2]])
            if(diff > 0.15): # 如果飞行不稳定则继续等待
                keep_waiting=1
                break
            if(theta < START_ANGLE): # 到指定角度开始移动钻圈
                keep_waiting=0
                break
            time.sleep(0.05)
        if keep_waiting==0:
            print("钻!    ")
            break
        
    # 环y轴20°时给飞机一个环y轴方向的目标点
    for __ in range(15): # 钻环最多1.5秒，防止撞环后失控
        wait_point = calc_wait_point(ring1_mc_pose, ring1_mc_mat, SPIN_RADIUS)
        # kuadmini_0.goto(wait_point[0], wait_point[1], wait_point[2])
        dest_point = [wait_point[0] + ring1_mc_mat[1][0]*0.4, wait_point[1] + ring1_mc_mat[1][1]*0.4, wait_point[2] + ring1_mc_mat[1][2]*0.4 - 0.1] # 顺势下降一点高度
        dest_x, dest_y, dest_z = goto_limit([kuadmini_0.mc_x, kuadmini_0.mc_y, kuadmini_0.mc_z], dest_point, 0.35)
        show_arrow_now(pub, wait_point, dest_point, 1, Color_Blue)
        kuadmini_0.goto(dest_x, dest_y, dest_z)
        diff = np.linalg.norm([kuadmini_0.mc_x-dest_point[0], kuadmini_0.mc_y-dest_point[1], kuadmini_0.mc_z-dest_point[2]])
        if(diff < 0.05):
            break
        time.sleep(0.1)

    # 完成穿越，降落
    print("降落    ")
    kuadmini_0.land()


    # for __ in range(5):
    #     kuadmini_0.takeoff()
    #     time.sleep(0.1)
    
    # while not rospy.is_shutdown():
    #     d_x = car_mc_x-kuadmini_0.mc_x
    #     d_y = car_mc_y-kuadmini_0.mc_y
    #     d_z = car_mc_z+0.2-kuadmini_0.mc_z
    #     length = np.sqrt(d_x*d_x + d_y*d_y + d_z*d_z)
    #     limit_k = 1.0
    #     if length > 0.3:
    #         limit_k = 0.3/length
    #     dest_x = kuadmini_0.mc_x + d_x*limit_k
    #     dest_y = kuadmini_0.mc_y + d_y*limit_k
    #     dest_z = kuadmini_0.mc_z + d_z*limit_k
    #     show_pos_now(pub, [car_mc_x, car_mc_y, car_mc_z], 0)
    #     show_pos_now(pub, [dest_x, dest_y, dest_z], 1)
    #     show_pos_now(pub, [kuadmini_0.mc_x, kuadmini_0.mc_y, kuadmini_0.mc_z], 2)
    #     kuadmini_0.goto(dest_x, dest_y, dest_z)
    #     time.sleep(0.1)

    # goHover(kuadmini_0)# kuadmini_0, kuadmini_1, kuadmini_2,
    # goSwings((kuadmini_0,))
    # goTrajactory((kuadmini_0, kuadmini_1, kuadmini_2, ), pub, "square.txt")

    while not rospy.is_shutdown():
        pass

